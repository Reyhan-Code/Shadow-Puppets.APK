package com.dicoding.shadowpuppets

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var rvWayang : RecyclerView
    private val list = ArrayList<Wayang>()

    companion object{
        val INTENT_PARCEABLE = "OBJECT_INTENT"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rvWayang = findViewById(R.id.rv_heroes)
        rvWayang.setHasFixedSize(true)

        list.addAll(getListWayang())
        showRecyclerList()

    }

    //ambil data pada string
    private fun getListWayang(): ArrayList<Wayang> {
        val dataName = resources.getStringArray(R.array.data_name)
        val dataDescription = resources.getStringArray(R.array.data_description)
        val dataPhoto = resources.obtainTypedArray(R.array.data_photo)
        val dataName2 = resources.getStringArray(R.array.name2)
        val dataAsal = resources.getStringArray(R.array.asal)
        val dataDetail = resources.getStringArray(R.array.detail)
        val dataUrl = resources.getStringArray(R.array.shareUrl)
        val listWayang = ArrayList<Wayang>()
        for (i in dataName.indices){
            val wayang = Wayang(dataName[i], dataDescription[i], dataPhoto.getResourceId(i, -1), dataName2[i], dataAsal[i],dataDetail[i], dataUrl[i]  )
            listWayang.add(wayang)
        }
        return listWayang
    }

    private fun showRecyclerList() {
        rvWayang.layoutManager = LinearLayoutManager(this)
        val listWayangAdapter = ListWayangAdapter(list)
        rvWayang.adapter = listWayangAdapter

        listWayangAdapter.setOnItemClickCallback(object : ListWayangAdapter.OnClickCallback {
            override fun onItemClicked(data: Wayang) {
                showSelectedWayang(data)
            }
        })
    }


    private fun showSelectedWayang(wayang: Wayang){
        Toast.makeText(this, "Kamu memilih " + wayang.name, Toast.LENGTH_SHORT).show()

        val intent = Intent(this, DetailWayang::class.java)
        intent.putExtra(INTENT_PARCEABLE, wayang)
        startActivity(intent)


    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return super.onCreateOptionsMenu(menu)
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.action_list ->{
                rvWayang.layoutManager = LinearLayoutManager(this)
            }
            R.id.action_grid -> {
                rvWayang.layoutManager = GridLayoutManager(this, 2)
            }
            R.id.about_page -> {
                val moveIntent = Intent(this@MainActivity, About::class.java)
                startActivity(moveIntent)
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
}
