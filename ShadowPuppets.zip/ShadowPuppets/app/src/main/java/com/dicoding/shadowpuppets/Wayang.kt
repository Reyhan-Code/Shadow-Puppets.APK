package com.dicoding.shadowpuppets

import android.os.Parcelable
import android.provider.ContactsContract.DisplayPhoto
import kotlinx.parcelize.Parcelize

@Parcelize
data class Wayang(
    val name: String,
    val description: String,
    val photo: Int,
    val name2: String,
    val asal: String,
    val detail: String,
    val urlWayang :String
): Parcelable




