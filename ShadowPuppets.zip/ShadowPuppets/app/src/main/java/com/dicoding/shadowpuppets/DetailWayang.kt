package com.dicoding.shadowpuppets

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import java.net.URL

class DetailWayang : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_wayang)

        supportActionBar?.apply {
            title = getString(R.string.detail_wayang)
        }

        val detailwayang = intent.getParcelableExtra<Wayang>(MainActivity.INTENT_PARCEABLE)

        val photo = findViewById<ImageView>(R.id.photo_img)
        val name = findViewById<TextView>(R.id.name_detail)
        val name2 = findViewById<TextView>(R.id.name_kedua)
        val asal = findViewById<TextView>(R.id.asal_wayang)
        val detail = findViewById<TextView>(R.id.description)


    photo.setImageResource(detailwayang?.photo!!)
        name.text = detailwayang.name
        name2.text= detailwayang.name2
        asal.text= detailwayang.asal
        detail.text= detailwayang.detail


    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menudetail, menu)
        return super.onCreateOptionsMenu(menu)


    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val dataName = resources.getStringArray(R.array.data_name)
        val dataUrl = resources.getStringArray(R.array.shareUrl)

        when (item.itemId) {
            R.id.action_share -> {
                val shareText = StringBuilder()
                for (i in dataName.indices) {
                    val name = dataName[i]
                    val url = if (i < dataUrl.size) dataUrl[i] else ""
                    shareText.append("$name: $url").append("\n")
                }
                val intent = Intent(Intent.ACTION_SEND)
                intent.type = "text/plain"
                intent.putExtra(Intent.EXTRA_TEXT, shareText.toString())
                val chooser = Intent.createChooser(intent, "Share Using..")
                startActivity(chooser)
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

}