package com.dicoding.shadowpuppets

import android.view.LayoutInflater
import android.view.OnReceiveContentListener
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

class ListWayangAdapter(private val listWayang: ArrayList<Wayang>) : RecyclerView.Adapter<ListWayangAdapter.ListViewHolder>() {

    private lateinit var onItemClickCallback: OnClickCallback

    fun setOnItemClickCallback(onItemClickCallback: OnClickCallback){
        this.onItemClickCallback = onItemClickCallback
    }




    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListViewHolder {
       val view: View = LayoutInflater.from(parent.context).inflate(R.layout.item_row_hero, parent, false)
        return ListViewHolder(view)
    }


    //list wayang
    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        val (name, description, photo) = listWayang[position]
        holder.imgPhoto.setImageResource(photo)
        holder.tvName.text = name
        holder.tvDescription.text = description

        holder.itemView.setOnClickListener{onItemClickCallback.onItemClicked(listWayang[holder.adapterPosition])//mengklik setiap item list
        }
    }

    override fun getItemCount(): Int = listWayang.size

        interface OnClickCallback{
                fun onItemClicked(data: Wayang)
        }

    class ListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imgPhoto: ImageView = itemView.findViewById(R.id.img_item_photo)
        val tvName: TextView = itemView.findViewById(R.id.tv_item_name)
        val tvDescription: TextView = itemView.findViewById(R.id.tv_item_description)


        fun bindView(wayang: Wayang, listener: (Wayang)-> Unit){
            imgPhoto.setImageResource(wayang.photo)
            tvName.text = wayang.name
            tvDescription.text = wayang.description
            itemView.setOnClickListener{
                listener(wayang)
            }
        }
    }
}